<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style>
#app {
  min-height: calc(100vh - 8px);
  width: 100vw;
  font-size: 10px;
  background-color: #2f2f31;
  margin: -8px;
  overflow: hidden !important;
}
</style>
